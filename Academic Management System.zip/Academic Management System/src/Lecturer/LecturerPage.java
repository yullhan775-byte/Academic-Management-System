package Lecturer;

import java.io.*;
import javax.swing.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import Login.LoginPage;

public class LecturerPage extends javax.swing.JFrame {
        
    public LecturerPage(){
        initComponents();
        loadUserInfo();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        assessment_type_btn = new javax.swing.JButton();
        assessment_result_btn = new javax.swing.JButton();
        Logout_btn = new javax.swing.JButton();
        assessment_feedback_btn = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        display_user_name = new javax.swing.JTextField();
        display_age = new javax.swing.JTextField();
        display_school = new javax.swing.JTextField();
        display_email = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        save_changes_btn = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        display_bod = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        userNameLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        assessment_type_btn.setFont(new java.awt.Font("STXinwei", 1, 18)); // NOI18N
        assessment_type_btn.setText("Assessment Types");
        assessment_type_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                assessment_type_btnActionPerformed(evt);
            }
        });

        assessment_result_btn.setFont(new java.awt.Font("STXinwei", 1, 18)); // NOI18N
        assessment_result_btn.setText("Assessment Results");
        assessment_result_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                assessment_result_btnActionPerformed(evt);
            }
        });

        Logout_btn.setFont(new java.awt.Font("STXinwei", 3, 16)); // NOI18N
        Logout_btn.setText("Logout");
        Logout_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Logout_btnActionPerformed(evt);
            }
        });

        assessment_feedback_btn.setFont(new java.awt.Font("STXinwei", 1, 18)); // NOI18N
        assessment_feedback_btn.setText("Assessment Feedback");
        assessment_feedback_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                assessment_feedback_btnActionPerformed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(300, 247));

        display_user_name.setBackground(new java.awt.Color(204, 204, 255));
        display_user_name.setFont(new java.awt.Font("STSong", 1, 24)); // NOI18N
        display_user_name.setText("Name");
        display_user_name.setBorder(null);
        display_user_name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                display_user_nameActionPerformed(evt);
            }
        });

        display_age.setEditable(false);
        display_age.setBackground(new java.awt.Color(204, 204, 255));
        display_age.setFont(new java.awt.Font("STSong", 1, 24)); // NOI18N
        display_age.setText("Age");
        display_age.setBorder(null);
        display_age.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                display_ageActionPerformed(evt);
            }
        });

        display_school.setBackground(new java.awt.Color(204, 204, 255));
        display_school.setFont(new java.awt.Font("STSong", 1, 24)); // NOI18N
        display_school.setText("School of XXX");
        display_school.setBorder(null);
        display_school.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                display_schoolActionPerformed(evt);
            }
        });

        display_email.setBackground(new java.awt.Color(204, 204, 255));
        display_email.setFont(new java.awt.Font("STSong", 1, 24)); // NOI18N
        display_email.setText("Email");
        display_email.setBorder(null);
        display_email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                display_emailActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setText("User Profile");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel3.setText("Name");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel4.setText("Age");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel5.setText("Email");

        save_changes_btn.setFont(new java.awt.Font("Segoe UI", 0, 17)); // NOI18N
        save_changes_btn.setText("Save Changes");
        save_changes_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                save_changes_btnActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel6.setText("Functional Area(s)");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel7.setText("Date of Birth");

        display_bod.setBackground(new java.awt.Color(204, 204, 255));
        display_bod.setFont(new java.awt.Font("STSong", 1, 24)); // NOI18N
        display_bod.setText("BOD");
        display_bod.setBorder(null);
        display_bod.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                display_bodActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(jLabel5)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(display_school)
                        .addComponent(display_email)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                            .addComponent(jLabel2)
                            .addGap(67, 67, 67))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel3)
                                .addComponent(display_user_name, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(display_age, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel4)))))
                .addGap(99, 99, 99))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7)
                            .addComponent(display_bod, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(86, 86, 86)
                        .addComponent(save_changes_btn)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(7, 7, 7)
                        .addComponent(jLabel4)
                        .addGap(4, 4, 4)
                        .addComponent(display_age, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(4, 4, 4)
                        .addComponent(display_user_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7)
                .addGap(4, 4, 4)
                .addComponent(display_bod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(display_email, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(display_school, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(save_changes_btn)
                .addGap(15, 15, 15))
        );

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("Welcome,");

        userNameLabel.setFont(new java.awt.Font("STSong", 1, 20)); // NOI18N
        userNameLabel.setText("Name");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(assessment_type_btn)
                    .addComponent(assessment_result_btn)
                    .addComponent(assessment_feedback_btn)
                    .addComponent(Logout_btn)
                    .addComponent(userNameLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 315, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(userNameLabel)
                .addGap(44, 44, 44)
                .addComponent(assessment_type_btn)
                .addGap(55, 55, 55)
                .addComponent(assessment_result_btn)
                .addGap(58, 58, 58)
                .addComponent(assessment_feedback_btn)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Logout_btn)
                .addGap(14, 14, 14))
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 415, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void assessment_type_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_assessment_type_btnActionPerformed
        new AssessmentDashboard(display_user_name.getText()).setVisible(true);
    }//GEN-LAST:event_assessment_type_btnActionPerformed

    private void assessment_result_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_assessment_result_btnActionPerformed
        new AssessmentMarks(display_user_name.getText()).setVisible(true);
    }//GEN-LAST:event_assessment_result_btnActionPerformed

    private void Logout_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Logout_btnActionPerformed
        new LoginPage().setVisible(true);
        dispose();
    }//GEN-LAST:event_Logout_btnActionPerformed

    private void assessment_feedback_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_assessment_feedback_btnActionPerformed
        new AssessmentFeedback(display_user_name.getText()).setVisible(true);
    }//GEN-LAST:event_assessment_feedback_btnActionPerformed

    private void display_user_nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_display_user_nameActionPerformed

    }//GEN-LAST:event_display_user_nameActionPerformed

    private void display_ageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_display_ageActionPerformed
        
    }//GEN-LAST:event_display_ageActionPerformed

    private void display_schoolActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_display_schoolActionPerformed
        
    }//GEN-LAST:event_display_schoolActionPerformed

    private void display_emailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_display_emailActionPerformed
        
    }//GEN-LAST:event_display_emailActionPerformed

    private void save_changes_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_save_changes_btnActionPerformed
        StringBuilder updatedData = new StringBuilder();

        String newName = display_user_name.getText().trim();
        String newEmail = display_email.getText().trim();
        String newSchool = display_school.getText().trim();
        String newDob = display_bod.getText().trim(); // yyyy-MM-dd

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate dob;

        // validating DOB
        try {
            dob = LocalDate.parse(newDob, formatter);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Invalid DOB format. Use yyyy-MM-dd");
            return;
        }

        try (BufferedReader br = new BufferedReader(new FileReader("users.txt"))) {
            String line;

            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) {
                    updatedData.append("\n");
                    continue;
                }

                String[] data = line.split(",");

                String fileUsername = data[1].trim();

                //if this matches the logged in user, update details
                if (fileUsername.equalsIgnoreCase(LoginPage.loggedInUsername.trim())) {
                    data[0] = newName;    // Name
                    data[3] = newEmail;   // Email
                    data[4] = newSchool;  // School
                    data[6] = newDob;     // DOB
                }

                updatedData.append(String.join(",", data)).append("\n");
            }

        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading users file");
            return;
        }

        //write updated content back to file
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("users.txt"))) {
            bw.write(updatedData.toString());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving user data");
            return;
    }

    // update page data after save
    userNameLabel.setText(newName);

    int age = Period.between(dob, LocalDate.now()).getYears();
    display_age.setText(String.valueOf(age));

    JOptionPane.showMessageDialog(this, "Profile updated successfully!");
    }//GEN-LAST:event_save_changes_btnActionPerformed

    private void display_bodActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_display_bodActionPerformed
        
    }//GEN-LAST:event_display_bodActionPerformed
    
    private void loadUserInfo() {
        try (BufferedReader br = new BufferedReader(new FileReader("users.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;

                String[] data = line.split(",");
                // data[0]=name, data[1]=username, data[2]=password, data[3]=email, data[4]=school, data[5]=role, data[6]=dob

                String fileUsername = data[1].trim();
                String fileRole = data[5].trim();
                
                //display data
                if (fileUsername.equalsIgnoreCase(LoginPage.loggedInUsername.trim()) 
                    && fileRole.equalsIgnoreCase("Lecturer")) {
                    display_user_name.setText(data[0].trim()); // Name
                    
                    //calculate age
                    String dobStr = data[6].trim();
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                    LocalDate dob = LocalDate.parse(dobStr, formatter);
                    int age = Period.between(dob, LocalDate.now()).getYears();
                    display_age.setText(String.valueOf(age));
                    
                    display_bod.setText(data[6].trim());
                    display_email.setText(data[3].trim());   // Email
                    display_school.setText(data[4].trim());  // School
                    userNameLabel.setText(data[0].trim());   // Name on sidebar
                    break;
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Failed to load user info");
        }
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> {
            new LecturerPage().setVisible(true);
        });
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Logout_btn;
    private javax.swing.JButton assessment_feedback_btn;
    private javax.swing.JButton assessment_result_btn;
    private javax.swing.JButton assessment_type_btn;
    private javax.swing.JTextField display_age;
    private javax.swing.JTextField display_bod;
    private javax.swing.JTextField display_email;
    private javax.swing.JTextField display_school;
    private javax.swing.JTextField display_user_name;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton save_changes_btn;
    private javax.swing.JLabel userNameLabel;
    // End of variables declaration//GEN-END:variables
}
