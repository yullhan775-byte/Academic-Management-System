/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Lecturer;

import javax.swing.table.DefaultTableModel;

/**
 *
 * @author yullh
 */
public class AssessmentFeedback extends javax.swing.JFrame {
    private String lecturerName;
    private final Used_Methods.AssessmentManager assessmentManager = new Used_Methods.AssessmentManager();
    private final Used_Methods.SubmissionChecker submissionManager = new Used_Methods.SubmissionChecker();
    private final Used_Methods.CheckStudent userManager = new Used_Methods.CheckStudent(); // must have getStudentNameById(...)
    private final Used_Methods.FeedbackManager feedbackManager = new Used_Methods.FeedbackManager();

    private String activeArea = "strength";
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(AssessmentFeedback.class.getName());
    /**
     * Creates new form AssessmentFeedback
     */
    public AssessmentFeedback() {
       initComponents();
       wireUpExtraHandlers();
    }
    
    public AssessmentFeedback(String lecturerName) {
    initComponents();
    wireUpExtraHandlers();
    this.lecturerName = lecturerName;

    DefaultTableModel model = new DefaultTableModel(
        new Object[]{"Student ID", "Student Name", "Marks", "Grade"}, 0
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    feedbackTable.setModel(model);

    setResizable(false);
    setLocationRelativeTo(null);
    setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

    loadModulesForLecturer();
}
    
    private void loadModulesForLecturer() {
        moduleBox.removeAllItems();
        for (String m : assessmentManager.getModulesForLecturer(lecturerName)) {
            moduleBox.addItem(m);
        }
    }
    
    private void loadAssessments(String module) {
        assessmentBox.removeAllItems();
        for (Used_Methods.Assessment a : assessmentManager.getAssessmentsByModule(module)) {
            assessmentBox.addItem(a.getId());
        }
    }

    
    private void wireUpExtraHandlers() {
        // Track which text area is currently being edited (for Clear button)
        strengthArea.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusGained(java.awt.event.FocusEvent e) {
                activeArea = "strength";
            }
        });

        improveArea.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusGained(java.awt.event.FocusEvent e) {
                activeArea = "improvement";
            }
        });

        actionArea.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusGained(java.awt.event.FocusEvent e) {
                activeArea = "action";
            }
        });
    }
    
    private void clearActiveArea() {
        switch (activeArea) {
            case "strength" -> strengthArea.setText("");
            case "improvement" -> improveArea.setText("");
            case "action" -> actionArea.setText("");
            default -> strengthArea.setText("");
        }
    }
    
    private void saveFeedback() {
    int row = feedbackTable.getSelectedRow();
    if (row == -1) {
        javax.swing.JOptionPane.showMessageDialog(this,
                "Please select a student first.",
                "No student selected",
                javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }

    String strength = sanitizeForPipe(strengthArea.getText());
    String improvement = sanitizeForPipe(improveArea.getText());
    String actionPlan = sanitizeForPipe(actionArea.getText());

    if (strength.isBlank() && improvement.isBlank() && actionPlan.isBlank()) {
        javax.swing.JOptionPane.showMessageDialog(this,
                "Please enter feedback before saving.",
                "Empty feedback",
                javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }

    String feedbackId = feedbackManager.generateFeedbackId();

    try {
        feedbackManager.saveFeedback(feedbackId, strength, improvement, actionPlan, lecturerName);//error

        javax.swing.JOptionPane.showMessageDialog(this,
                "Feedback saved successfully.",
                "Success",
                javax.swing.JOptionPane.INFORMATION_MESSAGE);

    } catch (Exception e) {
        e.printStackTrace();
        javax.swing.JOptionPane.showMessageDialog(this,
                "Error saving feedback.",
                "Error",
                javax.swing.JOptionPane.ERROR_MESSAGE);
    }
}
    
    private void loadSubmittedStudents(String module, String assessmentId) {
    DefaultTableModel model = (DefaultTableModel) feedbackTable.getModel();
    model.setRowCount(0);

    for (Used_Methods.SubmissionChecker.SubmissionRow r :
            submissionManager.getSubmittedRows(module, assessmentId)) {

        String studentName = userManager.getStudentNameById(r.studentId);

        model.addRow(new Object[]{
                r.studentId,
                studentName,
                r.marks.equalsIgnoreCase("NULL") ? "" : r.marks,
                r.grade.equalsIgnoreCase("NULL") ? "" : r.grade
        });
        }
    }

    private String sanitizeForPipe(String text) {
        if (text == null) return "";
        return text.replace("|", "/").replace("\r\n", "\n").replace("\n", "\\n").trim();
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        assessmentBox = new javax.swing.JComboBox<>();
        moduleBox = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        feedbackTable = new javax.swing.JTable();
        jScrollPane4 = new javax.swing.JScrollPane();
        improveArea = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        strengthArea = new javax.swing.JTextArea();
        clearButton = new javax.swing.JButton();
        saveButton = new javax.swing.JButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        actionArea = new javax.swing.JTextArea();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("Feedback");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("Assessment");

        assessmentBox.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        assessmentBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        assessmentBox.addActionListener(this::assessmentBoxActionPerformed);

        moduleBox.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        moduleBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        moduleBox.addActionListener(this::moduleBoxActionPerformed);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setText("Module");

        feedbackTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(feedbackTable);

        improveArea.setColumns(20);
        improveArea.setRows(5);
        jScrollPane4.setViewportView(improveArea);

        strengthArea.setColumns(20);
        strengthArea.setRows(5);
        jScrollPane3.setViewportView(strengthArea);

        clearButton.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        clearButton.setText("Clear");
        clearButton.addActionListener(this::clearButtonActionPerformed);

        saveButton.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        saveButton.setText("Save");
        saveButton.addActionListener(this::saveButtonActionPerformed);

        actionArea.setColumns(20);
        actionArea.setRows(5);
        jScrollPane5.setViewportView(actionArea);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("Action Plan");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setText("Improvement");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setText("Strength");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(moduleBox, 0, 304, Short.MAX_VALUE)
                            .addComponent(assessmentBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 655, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addComponent(clearButton, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(saveButton, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jScrollPane3)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(19, 19, 19))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(16, 16, 16))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(clearButton)
                            .addComponent(saveButton))
                        .addGap(28, 28, 28))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(moduleBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(assessmentBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 467, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(15, Short.MAX_VALUE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void moduleBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_moduleBoxActionPerformed
        // TODO add your handling code here:
    String selectedModule = (String) moduleBox.getSelectedItem();
    if (selectedModule != null) {
        loadAssessments(selectedModule);

        DefaultTableModel model = (DefaultTableModel) feedbackTable.getModel();
        model.setRowCount(0); // clear table when module changes
    }
    }//GEN-LAST:event_moduleBoxActionPerformed

    private void assessmentBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_assessmentBoxActionPerformed
        // TODO add your handling code here:
        String module = (String) moduleBox.getSelectedItem();
    String assessmentId = (String) assessmentBox.getSelectedItem();

    if (module != null && assessmentId != null) {
        loadSubmittedStudents(module, assessmentId);
    }
    }//GEN-LAST:event_assessmentBoxActionPerformed

    private void saveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveButtonActionPerformed
        // TODO add your handling code here:
        saveFeedback();
    }//GEN-LAST:event_saveButtonActionPerformed

    private void clearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearButtonActionPerformed
        // TODO add your handling code here:
        clearActiveArea();
    }//GEN-LAST:event_clearButtonActionPerformed
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new AssessmentFeedback().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea actionArea;
    private javax.swing.JComboBox<String> assessmentBox;
    private javax.swing.JButton clearButton;
    private javax.swing.JTable feedbackTable;
    private javax.swing.JTextArea improveArea;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JComboBox<String> moduleBox;
    private javax.swing.JButton saveButton;
    private javax.swing.JTextArea strengthArea;
    // End of variables declaration//GEN-END:variables
}
