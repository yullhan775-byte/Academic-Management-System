package Lecturer;

import Used_Methods.Assessment;
import Used_Methods.AssessmentManager;
import java.io.*;
import java.util.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class AssessmentDashboard extends javax.swing.JFrame {
    private String lecturerName;
    private final AssessmentManager manager = new AssessmentManager();

    DefaultTableModel model;
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(AssessmentDashboard.class.getName()); 
    
    public AssessmentDashboard(){
        initComponents();
    }

    public AssessmentDashboard(String lecturerName) {
        initComponents();
        typeBox.removeAllItems();
        typeBox.addItem("Assignment");
        typeBox.addItem("Quiz");
        typeBox.addItem("Final Exam");
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        this.lecturerName = lecturerName;
        initTable();
        loadLecturerModules();

        setLocationRelativeTo(null);
    }
    
    private void initTable() {
    model = new DefaultTableModel(
        new String[]{"ID", "Type", "Title", "Marks", "Weightage"}, 0
    );
    assessmentTable.setModel(model);
    }

    private void loadLecturerModules() {
        moduleBox.removeAllItems();
        for (String m : manager.getModulesForLecturer(lecturerName)) { //error
            moduleBox.addItem(m);
        }
    }
    
    private void loadAssessments(String module) {
        model.setRowCount(0);
        for (Assessment a : manager.getAssessmentsByModule(module)) { //error
            model.addRow(new Object[]{
                a.getId(),
                a.getType(),
                a.getTitle(),
                a.getMarks(),
                a.getWeightage()
            });
        }
    }
    
    private void clearFields() {
        titleField.setText("");
        marksField.setText("");
        weightField.setText("");
        typeBox.setSelectedIndex(0);
        assessmentTable.clearSelection();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        assessmentTable = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        marksField = new javax.swing.JTextField();
        titleField = new javax.swing.JTextField();
        weightField = new javax.swing.JTextField();
        typeBox = new javax.swing.JComboBox<>();
        moduleBox = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        createButton = new javax.swing.JButton();
        editButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        assessmentTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        assessmentTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                assessmentTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(assessmentTable);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setText("Design Assessment");

        marksField.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        marksField.setMaximumSize(null);
        marksField.addActionListener(this::marksFieldActionPerformed);

        titleField.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        titleField.setMaximumSize(null);

        weightField.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        weightField.setMaximumSize(null);

        typeBox.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        typeBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        typeBox.setMaximumSize(null);
        typeBox.addActionListener(this::typeBoxActionPerformed);

        moduleBox.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        moduleBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        moduleBox.setMaximumSize(null);
        moduleBox.addActionListener(this::moduleBoxActionPerformed);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setText("Module");

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("Assessment Type");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("Title");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setText("Marks");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setText("Weightage");

        createButton.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        createButton.setText("Create");
        createButton.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        createButton.addActionListener(this::createButtonActionPerformed);

        editButton.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        editButton.setText("Edit");
        editButton.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        editButton.addActionListener(this::editButtonActionPerformed);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 650, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel5)
                                        .addGap(111, 111, 111))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(marksField, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel6)
                                    .addComponent(weightField, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(titleField, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 287, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(editButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(createButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 287, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(typeBox, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(moduleBox, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(5, 5, 5)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(moduleBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel1)
                        .addGap(1, 1, 1)
                        .addComponent(typeBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(titleField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(marksField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(weightField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(createButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(editButton)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 562, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void marksFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_marksFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_marksFieldActionPerformed

    private void typeBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_typeBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_typeBoxActionPerformed

    private void createButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createButtonActionPerformed
        // TODO add your handling code here:
    String module = (String) moduleBox.getSelectedItem();
    String type = (String) typeBox.getSelectedItem();
    String title = titleField.getText().trim();
    String marksStr = marksField.getText().trim();
    String weightStr = weightField.getText().trim();

    if (module == null || type == null || title.isEmpty() || marksStr.isEmpty() || weightStr.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please fill all fields!");
        return;
    }

    int marks, weight;
    try {
        marks = Integer.parseInt(marksStr);
        weight = Integer.parseInt(weightStr);
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Marks and Weightage must be numbers!");
        return;
    }

    // generate ID using the manager instance (NOT static)
    String id = manager.generateAssessmentId(type);

    try {
        Assessment assessment = new Assessment(module, id, type, title, marks, weight);

        // save using manager instance (NOT static)
        manager.addAssessment(assessment);

        JOptionPane.showMessageDialog(this, "Assessment created successfully!");
        clearFields();
        loadAssessments(module);

    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Failed to create assessment.");
    }
    }//GEN-LAST:event_createButtonActionPerformed

    private void moduleBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_moduleBoxActionPerformed
        // TODO add your handling code here:
    String selectedModule = (String) moduleBox.getSelectedItem();

    if (selectedModule != null) {
        loadAssessments(selectedModule);
    }
    }//GEN-LAST:event_moduleBoxActionPerformed

    private void assessmentTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_assessmentTableMouseClicked
        // TODO add your handling code here:
        int selectedRow = assessmentTable.getSelectedRow();

        if (selectedRow >= 0) {
            typeBox.setSelectedItem(model.getValueAt(selectedRow, 1));
            titleField.setText(model.getValueAt(selectedRow, 2).toString());
            marksField.setText(model.getValueAt(selectedRow, 3).toString());
            weightField.setText(model.getValueAt(selectedRow, 4).toString());
        }
    }//GEN-LAST:event_assessmentTableMouseClicked

    private void editButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editButtonActionPerformed
        // TODO add your handling code here:
        int selectedRow = assessmentTable.getSelectedRow();
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Please select a row to edit!");
        return;
    }

    String module = (String) moduleBox.getSelectedItem();
    String id = model.getValueAt(selectedRow, 0).toString();
    String type = (String) typeBox.getSelectedItem();
    String title = titleField.getText().trim();
    String marksStr = marksField.getText().trim();
    String weightStr = weightField.getText().trim();

    if (title.isEmpty() || marksStr.isEmpty() || weightStr.isEmpty()) {
        JOptionPane.showMessageDialog(this, "All fields must be filled!");
        return;
    }

    try {
        int marks = Integer.parseInt(marksStr);
        int weight = Integer.parseInt(weightStr);

        Assessment updated = new Assessment(module, id, type, title, marks, weight);

        manager.updateAssessment(updated);

        JOptionPane.showMessageDialog(this, "Assessment updated successfully!");
        loadAssessments(module);
        clearFields();

    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Failed to update assessment.");
    }
    }//GEN-LAST:event_editButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new AssessmentDashboard().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable assessmentTable;
    private javax.swing.JButton createButton;
    private javax.swing.JButton editButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField marksField;
    private javax.swing.JComboBox<String> moduleBox;
    private javax.swing.JTextField titleField;
    private javax.swing.JComboBox<String> typeBox;
    private javax.swing.JTextField weightField;
    // End of variables declaration//GEN-END:variables
}
