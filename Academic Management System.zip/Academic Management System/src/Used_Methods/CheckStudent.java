/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Used_Methods;

import java.io.BufferedReader;
import java.io.FileReader;

/**
 *
 * @author yullh
 */
public class CheckStudent {
    private final String usersFile = "users.txt";

    public String getStudentNameById(String studentId) {
        try (BufferedReader br = new BufferedReader(new FileReader(usersFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;

                String[] parts = line.split(",");
                if (parts.length < 7) continue;

                String name = parts[0].trim();
                String id = parts[1].trim();
                String role = parts[5].trim();

                if (id.equalsIgnoreCase(studentId) && role.equalsIgnoreCase("Student")) {
                    return name;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return studentId;
    }
}
