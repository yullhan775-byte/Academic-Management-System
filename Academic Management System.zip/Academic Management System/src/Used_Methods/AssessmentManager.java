/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Used_Methods;

import java.io.*;
import java.util.*;

/**
 *
 * @author yullh
 */
public class AssessmentManager {

    private final String modulesFile = "modules.txt";
    private final String assessmentsFile = "assessments.txt";

    public List<String> getModulesForLecturer(String lecturerName) {
        List<String> modules = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(modulesFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] p = line.split(",");
                if (p.length >= 6) {
                    String moduleName = p[1].trim();
                    String lecturer = p[5].trim();
                    if (lecturer.equalsIgnoreCase(lecturerName)) {
                        modules.add(moduleName);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return modules;
    }

    public List<Assessment> getAssessmentsByModule(String module) {
        List<Assessment> list = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(assessmentsFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;

                String[] p = line.split(",");
                if (p.length < 6) continue;

                String fileModule = p[0].trim();
                if (!fileModule.equalsIgnoreCase(module)) continue;

                String id = p[1].trim();
                String type = p[2].trim();
                String title = p[3].trim();
                int marks = parseIntSafe(p[4].trim());
                int weight = parseIntSafe(p[5].trim());

                list.add(new Assessment(fileModule, id, type, title, marks, weight));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public void addAssessment(Assessment a) throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(assessmentsFile, true))) {
            bw.write(a.getModule() + "," + a.getId() + "," + a.getType() + "," + a.getTitle() + ","
                    + a.getMarks() + "," + a.getWeightage());
            bw.newLine();
        }
    }

    public void updateAssessment(Assessment updated) throws IOException {
        File inputFile = new File(assessmentsFile);
        File tempFile = new File("temp.txt");

        try (BufferedReader br = new BufferedReader(new FileReader(inputFile));
             BufferedWriter bw = new BufferedWriter(new FileWriter(tempFile))) {

            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) {
                    bw.newLine();
                    continue;
                }

                String[] p = line.split(",");
                if (p.length < 6) {
                    bw.write(line);
                    bw.newLine();
                    continue;
                }

                String id = p[1].trim();

                if (id.equals(updated.getId())) {
                    bw.write(updated.getModule() + "," + updated.getId() + "," + updated.getType() + ","
                            + updated.getTitle() + "," + updated.getMarks() + "," + updated.getWeightage());
                } else {
                    bw.write(line);
                }
                bw.newLine();
            }
        }

        inputFile.delete();
        tempFile.renameTo(inputFile);
    }

    public String generateAssessmentId(String type) {
        String prefix;
        switch (type) {
            case "Quiz" -> prefix = "Q";
            case "Final Exam" -> prefix = "F";
            default -> prefix = "A";
        }

        int count = 1;

        try (BufferedReader br = new BufferedReader(new FileReader(assessmentsFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                // safer check: id is column 2, not "contains"
                String[] p = line.split(",");
                if (p.length >= 2) {
                    String id = p[1].trim();
                    if (id.startsWith(prefix)) count++;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return prefix + String.format("%04d", count);
    }

    private int parseIntSafe(String s) {
        try { return Integer.parseInt(s); } catch (Exception e) { return 0; }
    }
}
