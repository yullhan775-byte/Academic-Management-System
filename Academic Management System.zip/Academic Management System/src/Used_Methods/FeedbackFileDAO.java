package Used_Methods;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class FeedbackFileDAO {

    private final String feedbackFilePath;

    public FeedbackFileDAO(String feedbackFilePath) {
        this.feedbackFilePath = feedbackFilePath;
    }

    public void save(Feedback feedback) throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(feedbackFilePath, true))) {
            bw.write(feedback.toFileLine());
            bw.newLine();
        }
    }
}
