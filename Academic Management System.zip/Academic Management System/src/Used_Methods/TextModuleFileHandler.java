package Used_Methods;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class TextModuleFileHandler extends ModuleFileHandler {

    private static final Logger logger =
            Logger.getLogger(TextModuleFileHandler.class.getName());

    @Override
    public boolean updateLecturer(String moduleCode, String lecturerName) {

        List<String> lines = new ArrayList<>();
        boolean updated = false;

        try (BufferedReader br = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;

            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",", -1);

                if (parts.length == 6 && parts[0].equals(moduleCode)) {
                    parts[5] = lecturerName;
                    line = String.join(",", parts);
                    updated = true;
                }

                lines.add(line);
            }

        } catch (IOException ex) {
            logger.log(Level.SEVERE, "Error reading modules file", ex);
            return false;
        }

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_NAME))) {
            for (String l : lines) {
                bw.write(l);
                bw.newLine();
            }
        } catch (IOException ex) {
            logger.log(Level.SEVERE, "Error writing modules file", ex);
            return false;
        }

        return updated;
    }
}
