/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Used_Methods;

import java.io.BufferedReader;
import java.io.FileReader;

/**
 *
 * @author yullh
 */
public class GradeManager {
    private final String gradesFile = "grades.txt";

    public String calculateGrade(int marks) {
        try (BufferedReader br = new BufferedReader(new FileReader(gradesFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("#") || line.trim().isEmpty()) continue;

                String[] parts = line.split("\\|");
                if (parts.length < 3) continue;

                int min = Integer.parseInt(parts[0].trim());
                int max = Integer.parseInt(parts[1].trim());
                String grade = parts[2].trim();

                if (marks >= min && marks <= max) return grade;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "F";
    }
}
