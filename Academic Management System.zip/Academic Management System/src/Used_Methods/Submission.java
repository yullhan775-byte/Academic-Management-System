/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Used_Methods;

/**
 *
 * @author yullh
 */
public class Submission {
    private String studentId;
    private String module;
    private String assessmentId;
    private String status;
    private String marks;
    private String grade;

    public Submission(String studentId, String module, String assessmentId, String status, String marks, String grade) {
        this.studentId = studentId;
        this.module = module;
        this.assessmentId = assessmentId;
        this.status = status;
        this.marks = marks;
        this.grade = grade;
    }

    public String getStudentId(){ 
        return studentId; 
    }
    
    public String getModule(){
        return module;
    }
    
    public String getAssessmentId() { 
        return assessmentId; 
    }
    
    public String getStatus() { 
        return status; 
    }
    
    public String getMarks(){
        return marks;
    }
    
    public String getGrade(){
        return grade;
    }
    
    public void setStatus(String status){
        this.status = status;
    }
    
    public void setMarks(String marks){
        this.marks = marks;
    }
    
    public void setGrade(String grade){
        this.grade = grade;
    }

    @Override
    public String toString() {
        return studentId + "," + module + "," + assessmentId + "," + status + "," + marks + "," + grade;
    }
}
