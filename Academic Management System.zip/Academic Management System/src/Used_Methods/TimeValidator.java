package Used_Methods;

public interface TimeValidator {
    boolean isValid(String startTime, String endTime);
    String getErrorMessage();
}
