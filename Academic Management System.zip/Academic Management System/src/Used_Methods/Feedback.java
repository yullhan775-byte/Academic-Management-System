package Used_Methods;

public class Feedback {
    private final String lecturerName;
    private final String moduleName;
    private final String q1;
    private final String q2;
    private final String improvement;

    public Feedback(String lecturerName, String moduleName, String q1, String q2, String improvement) {
        this.lecturerName = lecturerName;
        this.moduleName = moduleName;
        this.q1 = q1;
        this.q2 = q2;
        this.improvement = improvement;
    }

    public String toFileLine() {
        return lecturerName + "|" + moduleName + "|" + q1 + "|" + q2 + "|" + improvement;
    }
}
