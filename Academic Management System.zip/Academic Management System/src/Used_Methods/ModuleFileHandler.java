package Used_Methods;

public abstract class ModuleFileHandler {

    protected final String FILE_NAME = "modules.txt";

    // Abstract method
    public abstract boolean updateLecturer(String moduleCode, String lecturerName);
}
