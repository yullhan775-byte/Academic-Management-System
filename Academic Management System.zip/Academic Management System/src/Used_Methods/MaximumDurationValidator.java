package Used_Methods;

public class MaximumDurationValidator implements TimeValidator {

    @Override
    public boolean isValid(String startTime, String endTime) {
        // Simple example: max 2 hours duration
        int start = convertToMinutes(startTime);
        int end = convertToMinutes(endTime);
        return (end - start) <= 120;
    }

    @Override
    public String getErrorMessage() {
        return "Module duration cannot exceed 2 hours.";
    }

    private int convertToMinutes(String time) {
        // Example: "8:30 am"
        String[] parts = time.split("[: ]");
        int hour = Integer.parseInt(parts[0]);
        int min = Integer.parseInt(parts[1]);
        if (parts[2].equalsIgnoreCase("pm") && hour != 12) hour += 12;
        if (parts[2].equalsIgnoreCase("am") && hour == 12) hour = 0;
        return hour * 60 + min;
    }
}
