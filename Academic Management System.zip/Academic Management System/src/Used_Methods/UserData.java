/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Used_Methods;

/**
 *
 * @author yullh
 */
public class UserData {

    private String username;
    private String role;
    private String name;

    public UserData(String username, String role, String name, String dummy) {
        this.username = username;
        this.role = role;
        this.name = name;
    }

    public String getUsername() {
        return username;
    }

    public String getRole() {
        return role;
    }

    public String getName() {
        return name;
    }
}
