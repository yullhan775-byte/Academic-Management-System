package Used_Methods;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class UserFileDAO {

    private final String usersFilePath;

    public UserFileDAO(String usersFilePath) {
        this.usersFilePath = usersFilePath;
    }

    public String findFirstLecturerName() throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(usersFilePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;

                String[] parts = line.split("\\|");

                if (parts.length >= 6 && parts[5].trim().equalsIgnoreCase("lecturer")) {
                    return parts[0].trim();
                }
            }
        }
        return null;
    }
}
