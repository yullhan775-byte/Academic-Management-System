package Used_Methods;

public class Assessment {
    private final String module;
    private final String id;
    private final String type;
    private final String title;
    private final int marks;
    private final int weightage;

    public Assessment(String module, String id, String type, String title, int marks, int weightage) {
        this.module = module;
        this.id = id;
        this.type = type;
        this.title = title;
        this.marks = marks;
        this.weightage = weightage;
    }

    public String getModule() { 
        return module;
    }
    public String getId() { 
        return id;
    }
    public String getType() { 
        return type;
    }
    public String getTitle() { 
        return title;
    }
    public int getMarks() { 
        return marks;
    }
    public int getWeightage() { 
        return weightage;
    }
}
