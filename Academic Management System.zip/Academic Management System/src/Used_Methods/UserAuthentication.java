/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Used_Methods;

import java.io.*;

/**
 *
 * @author yullh
 */
public class UserAuthentication {

    public UserData authenticate(String username, String password) {

        try (BufferedReader reader = new BufferedReader(new FileReader("users.txt"))) {
            
            String line = reader.readLine(); // skip header

            while ((line = reader.readLine()) != null) {

                String[] parts = line.split(",");

                if (parts.length >= 7) {

                    String name = parts[0].trim();
                    String fileUser = parts[1].trim();
                    String filePass = parts[2].trim();
                    String role = parts[5].trim();

                    if (fileUser.equals(username) && filePass.equals(password)) {

                        return new UserData(
                                fileUser,
                                role.toUpperCase(),
                                name,
                                null
                        );
                    }
                }
            }

        } catch (Exception e) {
            System.out.println("Error reading users.txt");

            e.printStackTrace();
        }

        return null;
    }
    
}
