/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Used_Methods;

import java.io.*;
import java.util.*;

public class SubmissionChecker {
    private final String submissionsFile = "submissions.txt";
    private final String usersFile = "users.txt";

    public static class SubmissionRow {
        public final String studentId;
        public final String studentName;
        public final String module;
        public final String assessmentId;
        public final String status;
        public final String marks;
        public final String grade; 

        public SubmissionRow(String studentId, String studentName, String module, String assessmentId,
                             String status, String marks, String grade) {
            this.studentId = studentId;
            this.studentName = studentName;
            this.module = module;
            this.assessmentId = assessmentId;
            this.status = status;
            this.marks = marks;
            this.grade = grade;
        }
    }

    public List<SubmissionRow> getSubmittedRows(String module, String assessmentId) {
        List<SubmissionRow> rows = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(submissionsFile))) {
            String line = br.readLine(); // header
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;

                String[] p = line.split(",");
                if (p.length < 6) continue;

                String studentName = p[0].trim();
                String fileModule = p[1].trim();
                String fileAssessment = p[2].trim();
                String status = p[3].trim();
                String marks = p[4].trim();
                String grade = p[5].trim();

                if (fileModule.equalsIgnoreCase(module)
                        && fileAssessment.equalsIgnoreCase(assessmentId)
                        && status.equalsIgnoreCase("Submitted")) {
                    
                    String studentId = getStudentIdFromName(studentName);
                    if (studentId == null) studentId = "Unknown";

                    rows.add(new SubmissionRow(studentId, studentName, fileModule, fileAssessment, status, marks, grade));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return rows;
    }
    
    private String getStudentIdFromName(String studentName) {
        try (BufferedReader br = new BufferedReader(new FileReader(usersFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;

                String[] parts = line.split(",");
                if (parts.length < 7) continue;

                String name = parts[0].trim();
                String id = parts[1].trim();
                String role = parts[5].trim();

                if (name.equalsIgnoreCase(studentName) && role.equalsIgnoreCase("Student")) {
                    return id;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Apply marks/grade updates for a specific module+assessment.
     * updates: studentId -> marks (integer)
     * Grade should already be computed by caller (or you can pass another map).
     */
    public void updateMarksAndGrades(String module, String assessmentId,
                                    Map<String, Integer> marksByStudentId,
                                    Map<String, String> gradeByStudentId) throws IOException {

        List<String> updatedLines = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(submissionsFile))) {
            String header = br.readLine();
            if (header != null) updatedLines.add(header);

            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) {
                    updatedLines.add("");
                    continue;
                }

                String[] p = line.split(",");
                if (p.length < 6) {
                    updatedLines.add(line);
                    continue;
                }

                String studentId = p[0].trim();
                String fileModule = p[1].trim();
                String fileAssessment = p[2].trim();
                String status = p[3].trim();

                if (fileModule.equalsIgnoreCase(module)
                        && fileAssessment.equalsIgnoreCase(assessmentId)
                        && status.equalsIgnoreCase("Submitted")
                        && marksByStudentId.containsKey(studentId)) {

                    int marks = marksByStudentId.get(studentId);
                    String grade = gradeByStudentId.getOrDefault(studentId, "F");

                    p[4] = String.valueOf(marks);
                    p[5] = grade;
                }

                updatedLines.add(String.join(",", p));
            }
        }

        try (PrintWriter pw = new PrintWriter(new FileWriter(submissionsFile))) {
            for (String s : updatedLines) pw.println(s);
        }
    }
}
