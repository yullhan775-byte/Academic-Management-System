package Used_Methods;

import java.io.*;
import java.util.*;

public class UserManager {

    private List<User> users = new ArrayList<>();

    public UserManager(String filePath) {
        loadUsers(filePath);
    }

    private void loadUsers(String filePath) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;

            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()){
                    continue;
                }

                String[] data = line.split(",");

                // Skip header
                if (data[0].equalsIgnoreCase("name")){
                    continue;
                }

                String name = data[0];
                String username = data[1];
                String password = data[2];
                String role = data[5];

                users.add(new User(name, username, password, role));
            }
        } catch (IOException e) {
            System.out.println("Failed to load users file.");
        }
    }

    public User authenticate(String username, String password) {
        for (User u : users) {
            if (u.getUsername().equals(username) &&
                u.getPassword().equals(password)) {
                return u;
            }
        }
        return null;
    }
}
