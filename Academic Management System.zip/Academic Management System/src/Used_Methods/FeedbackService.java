package Used_Methods;

import java.io.IOException;

public class FeedbackService {

    private final UserFileDAO userDao;
    private final FeedbackFileDAO feedbackDao;

    public FeedbackService(UserFileDAO userDao, FeedbackFileDAO feedbackDao) {
        this.userDao = userDao;
        this.feedbackDao = feedbackDao;
    }

    public String getLecturerName() throws IOException {
        return userDao.findFirstLecturerName();
    }

    public void submitFeedback(Feedback feedback) throws IOException {
        feedbackDao.save(feedback);
    }
}
