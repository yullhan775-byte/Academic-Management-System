package Used_Methods;

public class Module {
    private String moduleCode;
    private String moduleName;
    private String startTime;
    private String endTime;
    private String classType;
    private String lecturerAssigned;

    public Module(String moduleCode, String moduleName, String startTime, String endTime, String classType, String lecturerAssigned) {
        this.moduleCode = moduleCode;
        this.moduleName = moduleName;
        this.startTime = startTime;
        this.endTime = endTime;
        this.classType = classType;
        this.lecturerAssigned = lecturerAssigned;
    }

    // Getter and Setter methods
    public String getModuleCode() {
        return moduleCode;
    }
    public void setModuleCode(String moduleCode) {
        this.moduleCode = moduleCode;
    }
    public String getModuleName() {
        return moduleName;
    }
    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }
    public String getStartTime() {
        return startTime;
    }
    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }
    public String getEndTime() {
        return endTime;
    }
    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }
    public String getClassType() {
        return classType;
    }
    public void setClassType(String classType) {
        this.classType = classType;
    }
    public String getLecturerAssigned() {
        return lecturerAssigned;
    }
    public void setLecturerAssigned(String lecturerAssigned) {
        this.lecturerAssigned = lecturerAssigned;
    }
}
