/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Used_Methods;

import Used_Methods.Submission;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author yullh
 */
public class SubmissionManager {

    private static final String ASSESS_FILE = "assessments.txt";
    private static final String SUBMIT_FILE = "submissions.txt";

    public static List<Object[]> getStudentAssessmentRows(
            String studentId, List<String> modules) {

        List<Object[]> rows = new ArrayList<>();
        List<Submission> submissions = loadAllSubmissions();

        try (BufferedReader br = new BufferedReader(new FileReader(ASSESS_FILE))) {

            br.readLine(); // skip header
            String line;

            while ((line = br.readLine()) != null) {

                String[] p = line.split(",");
                if (p.length < 4) continue;

                String module = p[0].trim();
                String assessmentId = p[1].trim();
                String type = p[2].trim();
                String title = p[3].trim();

                if (!modules.contains(module)) continue;

                Submission s =
                        findSubmission(submissions, studentId, module, assessmentId);

                String status =
                        (s == null) ? "Not Submitted" : s.getStatus();

                rows.add(new Object[]{
                        module, type, title, status, assessmentId
                });
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return rows;
    }

    public static void submit(String studentId, String module, String assessmentId) {

        List<Submission> submissions = loadAllSubmissions();

        // prevent duplicate submission
        if (findSubmission(submissions, studentId, module, assessmentId) != null) {
            JOptionPane.showMessageDialog(null, "You already submitted this assessment!");
            return;
        }

        File file = new File(SUBMIT_FILE);
        boolean fileExists = file.exists();

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(file, true))) {

            // write header ONLY if file did not exist
            if (!fileExists) {
                bw.write("studentId,module,assessmentId,status,marks,grade");
                bw.newLine();
            }

            bw.write(studentId + "," + module + "," + assessmentId
                    + ",Submitted,NULL,NULL");
            bw.newLine();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static List<Submission> loadAllSubmissions() {

        List<Submission> list = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(SUBMIT_FILE))) {
            String line;

            while ((line = br.readLine()) != null) {

                // skip header safely
                if (line.startsWith("studentId")) continue;

                String[] p = line.split(",");

                if (p.length >= 6) {
                    list.add(new Submission(
                            p[0].trim(), // studentId
                            p[1].trim(), // module
                            p[2].trim(), // assessmentId
                            p[3].trim(), // status
                            p[4].trim(), // marks
                            p[5].trim()  // grade
                    ));
                }
            }

        } catch (Exception e) {
            // file may not exist yet – safe to ignore
        }

        return list;
    }

    private static Submission findSubmission(
            List<Submission> list,
            String studentId,
            String module,
            String assessmentId) {

        for (Submission s : list) {
            if (s.getStudentId().equalsIgnoreCase(studentId)
                    && s.getModule().equalsIgnoreCase(module)
                    && s.getAssessmentId().equalsIgnoreCase(assessmentId)) {
                return s;
            }
        }
        return null;
    }
}