/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Used_Methods;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;

/**
 *
 * @author yullh
 */
public class FeedbackManager {
    private final String feedbackFile = "feedback.txt";

    public void saveFeedback(String feedbackId, String strength, String improvement,
                             String actionPlan, String lecturerName) throws Exception {

        String record = feedbackId + "|"
                + strength + "|"
                + improvement + "|"
                + actionPlan + "|"
                + lecturerName;

        try (FileWriter fw = new FileWriter(feedbackFile, true);
             BufferedWriter bw = new BufferedWriter(fw);
             PrintWriter out = new PrintWriter(bw)) {

            out.println(record);
        }
    }
    
    public String generateFeedbackId() {

    int max = 0;

    try (BufferedReader br = new BufferedReader(new FileReader(feedbackFile))) {

        String line;

        while ((line = br.readLine()) != null) {

            if (line.trim().isEmpty()) continue;

            String[] parts = line.split("\\|");

            String id = parts[0]; // FB001

            if (id.startsWith("FB")) {

                int num = Integer.parseInt(id.substring(2));

                if (num > max) {
                    max = num;
                }
            }
        }

    } catch (Exception e) {
        // file might not exist yet — that's fine
    }

    return "FB" + String.format("%03d", max + 1);
    }

}
