package Student;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

public class Check extends javax.swing.JFrame {
    private String studentId;
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Check.class.getName());

    public Check() {
    initComponents();  
    setLocationRelativeTo(null);
}
    
    public Check(String studentId) {
    initComponents();
    this.studentId = studentId;

    loadModules();          // fill moduleBox first
    setLocationRelativeTo(null);

    marks.setEditable(false);
    grades.setEditable(false);
}

    
    private void loadModules() {
    moduleBox.removeAllItems();

    try (BufferedReader br = new BufferedReader(new FileReader("submissions.txt"))) {
        br.readLine(); // header
        String line;

        java.util.Set<String> modules = new java.util.HashSet<>();

        while ((line = br.readLine()) != null) {
            if (line.trim().isEmpty()) continue;

            String[] p = line.split(",");
            if (p.length < 6) continue;

            if (p[0].trim().equalsIgnoreCase(studentId)) {
                modules.add(p[1].trim()); // module
            }
        }

        for (String m : modules) moduleBox.addItem(m);

    } catch (Exception e) {
        javax.swing.JOptionPane.showMessageDialog(this, "Error reading submissions.txt: " + e.getMessage());
    }
}

    private void loadAssessments(String selectedModule) {

    assessmentBox.removeAllItems();

    try (BufferedReader br = new BufferedReader(new FileReader("assessments.txt"))) {

        String line;

        // if you have a header, skip it safely:
        line = br.readLine();
        // if first line is NOT a header, comment the line above

        while ((line = br.readLine()) != null) {
            if (line.trim().isEmpty()) continue;

            String[] p = line.split(",");
            if (p.length < 2) continue;

            String fileModule = p[0].trim();
            String assessmentId = p[1].trim();

            if (fileModule.equalsIgnoreCase(selectedModule)) {
                assessmentBox.addItem(assessmentId);
            }
        }

    } catch (Exception e) {
        e.printStackTrace();
        javax.swing.JOptionPane.showMessageDialog(this, "Error reading assessments.txt: " + e.getMessage());
    }
}


    private void loadResult(String selectedModule, String selectedAssessment) {

    try (BufferedReader br = new BufferedReader(new FileReader("submissions.txt"))) {
        br.readLine();
        String line;

        while ((line = br.readLine()) != null) {
            if (line.trim().isEmpty()) continue;

            String[] p = line.split(",");
            if (p.length < 6) continue;

            if (p[0].trim().equalsIgnoreCase(studentId)
                    && p[1].trim().equalsIgnoreCase(selectedModule)
                    && p[2].trim().equalsIgnoreCase(selectedAssessment)) {

                String marksValue = p[4].trim();
                String gradeValue = p[5].trim();

                if (!marksValue.equalsIgnoreCase("NULL")) {
                    marks.setText(marksValue);
                    grades.setText(gradeValue.equalsIgnoreCase("NULL") ? "-" : gradeValue);
                } else {
                    marks.setText("Not graded yet");
                    grades.setText("-");
                }
                return;
            }
        }

        marks.setText("-");
        grades.setText("-");

    } catch (Exception e) {
        javax.swing.JOptionPane.showMessageDialog(this, "Error reading submissions.txt: " + e.getMessage());
    }
}

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        marks = new javax.swing.JTextField();
        grades = new javax.swing.JTextField();
        previous_page_btn = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        assessmentBox = new javax.swing.JComboBox<>();
        moduleBox = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel1.setText("Results");

        jLabel2.setText("Module  : ");

        jLabel3.setText("Marks     : ");

        jLabel4.setText("Grade     : ");

        marks.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                marksActionPerformed(evt);
            }
        });

        grades.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gradesActionPerformed(evt);
            }
        });

        previous_page_btn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        previous_page_btn.setText("Previous Page");
        previous_page_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                previous_page_btnActionPerformed(evt);
            }
        });

        jLabel5.setText("Assessment :");

        assessmentBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        assessmentBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                assessmentBoxActionPerformed(evt);
            }
        });

        moduleBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        moduleBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                moduleBoxActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(previous_page_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(138, 138, 138))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(marks, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(grades, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(moduleBox, 0, 215, Short.MAX_VALUE)
                            .addComponent(assessmentBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(previous_page_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(moduleBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(assessmentBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(17, 17, 17)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(marks, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(grades, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(93, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void marksActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_marksActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_marksActionPerformed

    private void gradesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gradesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_gradesActionPerformed

    private void previous_page_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_previous_page_btnActionPerformed
        new StudentPage().setVisible(true);
        dispose();
    }//GEN-LAST:event_previous_page_btnActionPerformed

    private void moduleBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_moduleBoxActionPerformed
        // TODO add your handling code here:
        String module = (String) moduleBox.getSelectedItem();
    if (module != null) {
        loadAssessments(module);
    }
    }//GEN-LAST:event_moduleBoxActionPerformed

    private void assessmentBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_assessmentBoxActionPerformed
        // TODO add your handling code here:
         String module = (String) moduleBox.getSelectedItem();
    String assessmentId = (String) assessmentBox.getSelectedItem();

    if (module != null && assessmentId != null) {
        loadResult(module, assessmentId);
    }
    }//GEN-LAST:event_assessmentBoxActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(() -> new Check().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> assessmentBox;
    private javax.swing.JTextField grades;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField marks;
    private javax.swing.JComboBox<String> moduleBox;
    private javax.swing.JButton previous_page_btn;
    // End of variables declaration//GEN-END:variables
}
