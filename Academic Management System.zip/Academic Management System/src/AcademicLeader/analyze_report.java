package AcademicLeader;

import javax.swing.table.DefaultTableModel;
import java.io.*;
import javax.swing.JOptionPane;

public class analyze_report extends javax.swing.JFrame {
    
    public analyze_report() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        previous_page_btn = new javax.swing.JButton();
        refresh_btn = new javax.swing.JButton();
        report_tab = new javax.swing.JTabbedPane();
        module_allocation_pane = new javax.swing.JTabbedPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        module_allocation_tbl = new javax.swing.JTable();
        jScrollPane4 = new javax.swing.JScrollPane();
        jPanel3 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        total_modules_lbl = new javax.swing.JLabel();
        assigned_modules_lbl = new javax.swing.JLabel();
        unassigned_modules_lbl = new javax.swing.JLabel();
        total_lecturers_lbl = new javax.swing.JLabel();
        total_lectures_lbl = new javax.swing.JLabel();
        total_tutorials_lbl = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Sitka Text", 1, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Reports");

        previous_page_btn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        previous_page_btn.setText("Previous Page");
        previous_page_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                previous_page_btnActionPerformed(evt);
            }
        });

        refresh_btn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        refresh_btn.setText("Refresh");
        refresh_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refresh_btnActionPerformed(evt);
            }
        });

        jScrollPane1.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N

        module_allocation_tbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(module_allocation_tbl);

        module_allocation_pane.addTab("Module Allocation", jScrollPane1);

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel8.setText("Total Modules:");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel9.setText("Assigned Modules:");

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel10.setText("Unassigned Modules:");

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel11.setText("Total Lecturers:");

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel12.setText("Total Lectures:");

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel13.setText("Total Tutorials:");

        total_modules_lbl.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        total_modules_lbl.setText("jLabel2");

        assigned_modules_lbl.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        assigned_modules_lbl.setText("jLabel2");

        unassigned_modules_lbl.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        unassigned_modules_lbl.setText("jLabel2");

        total_lecturers_lbl.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        total_lecturers_lbl.setText("jLabel2");

        total_lectures_lbl.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        total_lectures_lbl.setText("jLabel2");

        total_tutorials_lbl.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        total_tutorials_lbl.setText("jLabel2");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9)
                    .addComponent(jLabel10)
                    .addComponent(jLabel11)
                    .addComponent(jLabel12)
                    .addComponent(jLabel13))
                .addGap(63, 63, 63)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(total_modules_lbl, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE)
                    .addComponent(assigned_modules_lbl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(unassigned_modules_lbl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(total_lecturers_lbl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(total_lectures_lbl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(total_tutorials_lbl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(125, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(total_modules_lbl))
                .addGap(27, 27, 27)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(assigned_modules_lbl))
                .addGap(26, 26, 26)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(unassigned_modules_lbl))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(total_lecturers_lbl))
                .addGap(32, 32, 32)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(total_lectures_lbl))
                .addGap(28, 28, 28)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(total_tutorials_lbl))
                .addGap(31, 31, 31))
        );

        jScrollPane4.setViewportView(jPanel3);

        module_allocation_pane.addTab("Summary Statistics", jScrollPane4);

        report_tab.addTab("Analyze Reports", module_allocation_pane);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(previous_page_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(224, 224, 224)
                        .addComponent(jLabel1))
                    .addComponent(refresh_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(report_tab, javax.swing.GroupLayout.PREFERRED_SIZE, 850, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(previous_page_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addComponent(refresh_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(report_tab, javax.swing.GroupLayout.PREFERRED_SIZE, 390, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void previous_page_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_previous_page_btnActionPerformed
        new LeaderPage().setVisible(true);
        dispose();
    }//GEN-LAST:event_previous_page_btnActionPerformed

    private void refresh_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refresh_btnActionPerformed
        loadModuleAllocationReport();
        updateSummaryStatistics();
    }//GEN-LAST:event_refresh_btnActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        loadModuleAllocationReport();
        updateSummaryStatistics();
    }//GEN-LAST:event_formWindowOpened

    private void loadModuleAllocationReport() {
        DefaultTableModel model = new DefaultTableModel(
            new String[]{
                "Module Code",
                "Module Name",
                "Start Time",
                "End Time",
                "Class Type",
                "Lecturer Assigned"
            }, 0
        );

        module_allocation_tbl.setModel(model);

        try (BufferedReader br = new BufferedReader(new FileReader("modules.txt"))) {
            String line;

            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",", -1);

                if (parts.length == 6) {
                    model.addRow(new Object[]{
                        parts[0], // module code
                        parts[1], // module name
                        parts[2], // start time
                        parts[3], // end time
                        parts[4], // class type
                        parts[5]  // lecturer assigned
                    });
                }
            }

        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading module allocation report");
        }
    }
    
    private void updateSummaryStatistics() {
        int totalModules = 0;

        java.util.List<String> assignedModulesList = new java.util.ArrayList<>();
        java.util.List<String> unassignedModulesList = new java.util.ArrayList<>();
        java.util.List<String> lectureModulesList = new java.util.ArrayList<>();
        java.util.List<String> tutorialModulesList = new java.util.ArrayList<>();
        java.util.List<String> lecturerUsersList = new java.util.ArrayList<>();

        // Read modules.txt
        try (BufferedReader br = new BufferedReader(new FileReader("modules.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                totalModules++;
                String[] parts = line.split(",", -1); //keeps empty strings

                if (parts.length >= 6) {
                    String moduleName = parts[1];
                    String classType = parts[4];
                    String lecturerAssigned = parts[5];

                    // check assign status
                    if (!lecturerAssigned.equalsIgnoreCase("NA") && !lecturerAssigned.isEmpty()) {
                        assignedModulesList.add(moduleName + " (" + lecturerAssigned + ")");
                    } else {
                        unassignedModulesList.add(moduleName);
                    }

                    // check class type
                    if (classType.equalsIgnoreCase("Lecture")) {
                        lectureModulesList.add(moduleName);
                    } else if (classType.equalsIgnoreCase("Tutorial")) {
                        tutorialModulesList.add(moduleName);
                    }
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading modules.txt for summary statistics");
        }

        // Read users.txt
        try (BufferedReader br = new BufferedReader(new FileReader("users.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",", -1); // name, username, password, email, department, role, BOD
                if (parts.length >= 6 && parts[5].equalsIgnoreCase("lecturer")) {
                    lecturerUsersList.add(parts[0]); //extract name
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading users.txt for lecturer list");
        }

        // 3. Update GUI labels
        total_modules_lbl.setText(String.valueOf(totalModules));
        assigned_modules_lbl.setText(String.join(", ", assignedModulesList));
        unassigned_modules_lbl.setText(String.join(", ", unassignedModulesList));
        total_lecturers_lbl.setText(String.join(", ", lecturerUsersList));
        total_lectures_lbl.setText(String.join(", ", lectureModulesList));
        total_tutorials_lbl.setText(String.join(", ", tutorialModulesList));
    }

    
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(() -> new analyze_report().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel assigned_modules_lbl;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTabbedPane module_allocation_pane;
    private javax.swing.JTable module_allocation_tbl;
    private javax.swing.JButton previous_page_btn;
    private javax.swing.JButton refresh_btn;
    private javax.swing.JTabbedPane report_tab;
    private javax.swing.JLabel total_lecturers_lbl;
    private javax.swing.JLabel total_lectures_lbl;
    private javax.swing.JLabel total_modules_lbl;
    private javax.swing.JLabel total_tutorials_lbl;
    private javax.swing.JLabel unassigned_modules_lbl;
    // End of variables declaration//GEN-END:variables
}
