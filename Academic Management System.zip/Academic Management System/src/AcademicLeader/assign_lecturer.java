package AcademicLeader;



import java.io.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import Used_Methods.ModuleFileHandler;
import Used_Methods.TextModuleFileHandler;

public class assign_lecturer extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(assign_lecturer.class.getName());

    public assign_lecturer() {
        initComponents();
        loadLecturers();
        
        module_table.getSelectionModel().addListSelectionListener(e -> {

        if (!e.getValueIsAdjusting()) {
            int selectedRow = module_table.getSelectedRow();
            
            if (selectedRow == -1) {
                lecturer_list.setEnabled(false);
                lecturer_list.setSelectedIndex(-1); // show nothing
                return;
            }

            lecturer_list.setEnabled(true);

            String moduleTitle = module_table.getValueAt(selectedRow, 1).toString();
            String classType = module_table.getValueAt(selectedRow, 4).toString();
            String lecturer = module_table.getValueAt(selectedRow, 5).toString();

            module_selected_field.setText(moduleTitle);
            class_type_field.setText(classType);
           
            // If module has no lecturer assigned
            if (lecturer == null || lecturer.trim().equalsIgnoreCase("NA") || lecturer.trim().isEmpty()) {
                lecturer_list.setSelectedIndex(-1); // nothing selected
            } else {
                lecturer_list.setSelectedItem(lecturer);
            }
        }
    }
        );
        loadModulestoTable();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        previous_page_btn = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        save_changes = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        module_table = new javax.swing.JTable();
        clear_btn = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        lecturer_list = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        module_selected_field = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        class_type_field = new javax.swing.JTextField();
        clear_lecturer_btn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(204, 255, 204));

        previous_page_btn.setText("Previous Page");
        previous_page_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                previous_page_btnActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Sitka Text", 1, 24)); // NOI18N
        jLabel1.setText("Assigning Lecturers");

        save_changes.setText("SAVE CHANGES");
        save_changes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                save_changesActionPerformed(evt);
            }
        });

        module_table.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        module_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Module Code", "Module Title", "Start Time", "End Time", "Class Type", "Lecturer Assigned"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(module_table);

        clear_btn.setText("CLEAR");
        clear_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clear_btnActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel3.setText("Assign a Lecturer:");

        lecturer_list.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lecturer_list.setEnabled(false);
        lecturer_list.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lecturer_listActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel4.setText("Class Type:");

        module_selected_field.setEditable(false);
        module_selected_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel5.setText("Module Selected:");

        class_type_field.setEditable(false);
        class_type_field.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        clear_lecturer_btn.setText("Clear Assigned Lecturer");
        clear_lecturer_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clear_lecturer_btnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(previous_page_btn)
                        .addGap(166, 166, 166)
                        .addComponent(jLabel1))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(clear_lecturer_btn)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 631, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(module_selected_field)
                            .addComponent(lecturer_list, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel3)
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(class_type_field, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                .addGap(0, 61, Short.MAX_VALUE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(save_changes)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(clear_btn)))))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1)
                            .addComponent(previous_page_btn))
                        .addGap(16, 16, 16)
                        .addComponent(clear_lecturer_btn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 295, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(18, 18, 18)
                        .addComponent(module_selected_field, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel4)
                        .addGap(18, 18, 18)
                        .addComponent(class_type_field, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addComponent(lecturer_list, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(save_changes)
                            .addComponent(clear_btn))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void previous_page_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_previous_page_btnActionPerformed
        new LeaderPage().setVisible(true);
        dispose();
    }//GEN-LAST:event_previous_page_btnActionPerformed

    private void save_changesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_save_changesActionPerformed
        int selectedRow = module_table.getSelectedRow();
        
        if (selectedRow == -1){
            JOptionPane.showMessageDialog(this,"Please select a module from the table.", "No Selection",JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        String selectedLecturer = (String) lecturer_list.getSelectedItem();
        
        if (selectedLecturer == null || "NA".equals(selectedLecturer)) {
            JOptionPane.showMessageDialog(this, 
                "Please select a lecturer to assign.", 
                "No Lecturer Selected", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        // Get module code from selected row
        String moduleCode = module_table.getValueAt(selectedRow, 0).toString();
        
        // Update the modules.txt file
        if (updateModuleFile(moduleCode, selectedLecturer)) {
            JOptionPane.showMessageDialog(this, 
                "Lecturer assigned successfully!", 
                "Success", 
                JOptionPane.INFORMATION_MESSAGE);
            
            // Reload the table to reflect changes
            loadModulestoTable();
            clearSelection();
        } else {
            JOptionPane.showMessageDialog(this, 
                "Failed to assign lecturer. Please try again.", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }                                  
    }//GEN-LAST:event_save_changesActionPerformed

    private void lecturer_listActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lecturer_listActionPerformed
    }//GEN-LAST:event_lecturer_listActionPerformed

    private void clear_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clear_btnActionPerformed
        clearSelection();
    }//GEN-LAST:event_clear_btnActionPerformed

    private void clear_lecturer_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clear_lecturer_btnActionPerformed
        int selectedRow = module_table.getSelectedRow();
        
        //make sure a row is selected
        if(selectedRow == -1){
            JOptionPane.showMessageDialog(this,"Please select a module first.","No Selection", JOptionPane.WARNING_MESSAGE);
        }
        DefaultTableModel model = (DefaultTableModel) module_table.getModel();
        
        String moduleCode = model.getValueAt(selectedRow, 0).toString();
        String lecturerName = model.getValueAt(selectedRow, 5).toString();
        
        //check if lecturer name is NA
        if (lecturerName.equalsIgnoreCase("NA") || lecturerName.isEmpty()) {
        JOptionPane.showMessageDialog(
                this,
                "This module has no lecturer assigned.",
                "Nothing to Clear",
                JOptionPane.INFORMATION_MESSAGE
        );
    }
        //clear lecturer assigned
        model.setValueAt("NA", selectedRow, 5);
        lecturer_list.setSelectedIndex(-1);
        
        //update to file
        boolean success = updateModuleFile(moduleCode, "NA");
        
        if (success) {
        JOptionPane.showMessageDialog(
                this,
                "Lecturer cleared successfully.",
                "Success",
                JOptionPane.INFORMATION_MESSAGE
        );
    } else {
        JOptionPane.showMessageDialog(
                this,
                "Failed to update module file.",
                "Error",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }//GEN-LAST:event_clear_lecturer_btnActionPerformed
    
     private boolean updateModuleFile(String moduleCode, String lecturerName) {
        ModuleFileHandler handler = new TextModuleFileHandler();
        return handler.updateLecturer(moduleCode, lecturerName);
    }
    
    private void loadModulestoTable() {
    DefaultTableModel model = (DefaultTableModel) module_table.getModel();
    model.setRowCount(0); // clear table first

    try (BufferedReader br = new BufferedReader(new FileReader("modules.txt"))) {
        String line;

        while ((line = br.readLine()) != null) {
            if (line.trim().isEmpty()) continue;

            String[] parts = line.split(",", -1);

            if (parts.length == 6) {
                model.addRow(new Object[]{parts[0], parts[1],parts[2], parts[3],parts[4], parts[5] });
            }
        }
    } catch (IOException ex) {
        JOptionPane.showMessageDialog(this,
            "Error loading modules: " + ex.getMessage(),
            "Error",
            JOptionPane.ERROR_MESSAGE);
    }
}

    private void loadLecturers() {
        lecturer_list.removeAllItems();

        try (BufferedReader br = new BufferedReader(new FileReader("users.txt"))) {
        String line;

        while ((line = br.readLine()) != null) {

            if (line.trim().isEmpty()) {
                continue;
            }

            String[] parts = line.split(",", -1);

            if (parts.length < 6) {
                continue;
            }

            String name = parts[0].trim();
            String role = parts[5].trim();

            //filter out lecturers
            if (role.equalsIgnoreCase("Lecturer")) {
                lecturer_list.addItem(name);
            }
        }

        lecturer_list.setSelectedIndex(-1);

        if (lecturer_list.getItemCount() == 0) {
            JOptionPane.showMessageDialog(
                this,
                "No lecturers found in users.txt",
                "Warning",
                JOptionPane.WARNING_MESSAGE
            );
        }

        }catch (IOException ex) {
            JOptionPane.showMessageDialog(
                this,
                "Error loading lecturers: " + ex.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE
            );
        }   
    }

    public void clearSelection(){
        module_table.clearSelection();
        module_selected_field.setText("");
        class_type_field.setText("");
        lecturer_list.setSelectedIndex(-1);
        lecturer_list.setEnabled(true);
        save_changes.setEnabled(true);
    }
    
    public static void main(String args[]) {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new assign_lecturer().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField class_type_field;
    private javax.swing.JButton clear_btn;
    private javax.swing.JButton clear_lecturer_btn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JComboBox<String> lecturer_list;
    private javax.swing.JTextField module_selected_field;
    private javax.swing.JTable module_table;
    private javax.swing.JButton previous_page_btn;
    private javax.swing.JButton save_changes;
    // End of variables declaration//GEN-END:variables
}
