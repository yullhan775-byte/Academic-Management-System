package AcademicLeader;

import java.io.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import Used_Methods.MaximumDurationValidator;
import Used_Methods.MinimumDurationValidator;
import Used_Methods.TimeValidator;
    
public class manage_module extends javax.swing.JFrame {
    
    public manage_module(){
        initComponents();
//        loadModulesFromFile();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jInternalFrame1 = new javax.swing.JInternalFrame();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        module_table = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        add_module_btn = new javax.swing.JButton();
        clear_btn = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        new_module_name = new javax.swing.JTextField();
        new_module_end_time = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        new_module_start_time = new javax.swing.JComboBox<>();
        new_module_type = new javax.swing.JComboBox<>();
        delete_btn = new javax.swing.JButton();
        previous_page_btn = new javax.swing.JButton();
        update_to_file_btn = new javax.swing.JButton();

        jInternalFrame1.setVisible(true);

        javax.swing.GroupLayout jInternalFrame1Layout = new javax.swing.GroupLayout(jInternalFrame1.getContentPane());
        jInternalFrame1.getContentPane().setLayout(jInternalFrame1Layout);
        jInternalFrame1Layout.setHorizontalGroup(
            jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jInternalFrame1Layout.setVerticalGroup(
            jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Manage_Modules");
        setMinimumSize(new java.awt.Dimension(829, 527));
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(255, 204, 102));

        jLabel1.setFont(new java.awt.Font("Sitka Text", 1, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Manage Modules");

        module_table.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        module_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Module Code", "Module Name", "Start Time", "End Time", "Class Type"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, true, true, true, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        module_table.setRowHeight(25);
        module_table.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                module_tableKeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(module_table);

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Add New Modules", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 18))); // NOI18N
        jPanel2.setOpaque(false);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Module Name");

        add_module_btn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        add_module_btn.setText("Add Module");
        add_module_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add_module_btnActionPerformed(evt);
            }
        });

        clear_btn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        clear_btn.setText("Clear");
        clear_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clear_btnActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel6.setText("Start Time");

        new_module_name.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        new_module_end_time.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        new_module_end_time.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "8:00 am", "8:30 am", "9:00 am", "9:30 am", "10:00 am", "10:30 am", "11:00 am", "11:30 am", "12:00 pm", "12:30 pm", "1:00 pm", "1:30 pm", "2.00 pm", "2:30 pm", "3:00 pm", "3:30 pm", "4:00 pm", "4:30 pm", "5:00 pm", "5:30 pm", "6:00 pm", "6:30 pm" }));
        new_module_end_time.setSelectedIndex(-1);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel7.setText("End Time");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel8.setText("Module Type");

        new_module_start_time.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        new_module_start_time.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "8:00 am", "8:30 am", "9:00 am", "9:30 am", "10:00 am", "10:30 am", "11:00 am", "11:30 am", "12:00 pm", "12:30 pm", "1:00 pm", "1:30 pm", "2.00 pm", "2:30 pm", "3:00 pm", "3:30 pm", "4:00 pm", "4:30 pm", "5:00 pm", "5:30 pm", "6:00 pm", "6:30 pm" }));
        new_module_start_time.setSelectedIndex(-1);

        new_module_type.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        new_module_type.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "LECTURE", "TUTORIAL" }));
        new_module_type.setSelectedIndex(-1);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel3)
                    .addComponent(new_module_name)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(add_module_btn)
                        .addGap(29, 29, 29)
                        .addComponent(clear_btn))
                    .addComponent(new_module_type, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(new_module_end_time, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(new_module_start_time, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(16, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(new_module_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(new_module_start_time, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(new_module_end_time, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(new_module_type, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(132, 132, 132)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(add_module_btn)
                    .addComponent(clear_btn))
                .addContainerGap())
        );

        jPanel2Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {add_module_btn, clear_btn});

        delete_btn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        delete_btn.setText("Delete");
        delete_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delete_btnActionPerformed(evt);
            }
        });

        previous_page_btn.setText("Previous Page");
        previous_page_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                previous_page_btnActionPerformed(evt);
            }
        });

        update_to_file_btn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        update_to_file_btn.setText("Update To File");
        update_to_file_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_to_file_btnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(previous_page_btn))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 67, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 525, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(delete_btn)
                        .addGap(18, 18, 18)
                        .addComponent(update_to_file_btn))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(previous_page_btn)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(delete_btn)
                            .addComponent(update_to_file_btn))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 425, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void add_module_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add_module_btnActionPerformed
        String module_name = new_module_name.getText().trim();
        String start_time = new_module_start_time.getSelectedItem() != null ? new_module_start_time.getSelectedItem().toString() : "";
        String end_time = new_module_end_time.getSelectedItem() != null ? new_module_end_time.getSelectedItem().toString() : "";
        String module_code = generate_module_code();
        String class_type = new_module_type.getSelectedItem() != null ? new_module_type.getSelectedItem().toString() : "";
        
        if (module_name.isEmpty()){
            JOptionPane.showMessageDialog(this, "Module Name is Empty!");
            return;
        }
        
        if (start_time.isEmpty()){
            JOptionPane.showMessageDialog(this, "Select a starting time!");
            return;
        }
        
        if (end_time.isEmpty()){
            JOptionPane.showMessageDialog(this, "Select an ending time!");
            return;
        }
        
        if (class_type.isEmpty()){
            JOptionPane.showMessageDialog(this, "Select a class type!");
            return;
        }
        
        TimeValidator[] validators = {
            new MinimumDurationValidator(),
            new MaximumDurationValidator()
        };

        for (TimeValidator v : validators) {
            if (!v.isValid(start_time, end_time)) {
                JOptionPane.showMessageDialog(this, v.getErrorMessage());
                return;
            }
        }
    
        DefaultTableModel model = (DefaultTableModel) module_table.getModel();
        model.addRow(new Object[]{
            module_code,
            module_name,
            start_time,
            end_time,
            class_type,
        });
        
        saveTableToFile();
        
        //clear user input after adding
        new_module_name.setText("");
        new_module_start_time.setSelectedIndex(-1);
        new_module_end_time.setSelectedIndex(-1);
        new_module_type.setSelectedIndex(-1);
    }//GEN-LAST:event_add_module_btnActionPerformed
           
    private String generate_module_code(){
        DefaultTableModel model = (DefaultTableModel) module_table.getModel();
        int maxCode = 0;

        for (int i = 0; i < model.getRowCount(); i++) {
            int code = Integer.parseInt(model.getValueAt(i, 0).toString());
            if (code > maxCode) maxCode = code;
        }
        return String.format("%03d", maxCode + 1);
    }
    
    private void clear_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clear_btnActionPerformed
        new_module_name.setText("");
        new_module_start_time.setSelectedIndex(-1);
        new_module_end_time.setSelectedIndex(-1);
        new_module_type.setSelectedIndex(-1);
        //refresh to show nothing
    }//GEN-LAST:event_clear_btnActionPerformed

    private void delete_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delete_btnActionPerformed
        if (module_table.isEditing()) {
            module_table.getCellEditor().stopCellEditing();
        }

        int select_row = module_table.getSelectedRow();

        if (select_row < 0){
            JOptionPane.showMessageDialog(this,"No Row is Selected, Please Select a Row.","Select Row",JOptionPane.ERROR_MESSAGE);
        } else {
            DefaultTableModel model = (DefaultTableModel) module_table.getModel();
            model.removeRow(select_row);
            saveTableToFile();
        }
    }//GEN-LAST:event_delete_btnActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        saveTableToFile();
    }//GEN-LAST:event_formWindowClosing

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        loadModulesFromFile();
    }//GEN-LAST:event_formWindowOpened

    private void loadModulesFromFile() {
        DefaultTableModel model = (DefaultTableModel) module_table.getModel();
        model.setRowCount(0); // clear table, but NOT file

        File file = new File("modules.txt");
        if (!file.exists()) {
            System.out.println("modules.txt not found. Table will be empty.");
            return;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",", -1);

                if (parts.length < 5) continue;

                Object[] rowData = new Object[5];
                for (int i = 0; i < 5; i++) {
                    rowData[i] = parts[i];
                }

                model.addRow(rowData);
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading modules.txt:\n" + e.getMessage(), "Load Error", JOptionPane.ERROR_MESSAGE);
        }
    }



    
    private void previous_page_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_previous_page_btnActionPerformed
        new LeaderPage().setVisible(true);
        dispose();
    }//GEN-LAST:event_previous_page_btnActionPerformed

    private void module_tableKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_module_tableKeyPressed
        // Check if Enter key is pressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            // Only process if a cell was actually being edited
            if (!module_table.isEditing()) {
                return; // No editing happening, do nothing
            }

            // Stop cell editing
            module_table.getCellEditor().stopCellEditing();

            // Get the selected row and column
            int row = module_table.getSelectedRow();
            int column = module_table.getSelectedColumn();

            // Validate if time columns were edited
            if (row >= 0 && (column == 2 || column == 3)) {
                String start_time = module_table.getValueAt(row, 2).toString();
                String end_time = module_table.getValueAt(row, 3).toString();

                TimeValidator[] validators = {
                    new MinimumDurationValidator(),
                    new MaximumDurationValidator()
                };

                for (TimeValidator v : validators) {
                    if (!v.isValid(start_time, end_time)) {
                        JOptionPane.showMessageDialog(this, "Row " + (row + 1) + ": " + v.getErrorMessage());
                        // Reload data from file if validation fails
                        loadModulesFromFile();
                        return;
                    }
                }
            }

            // Save the table to file only if we actually edited something
            saveTableToFile();

            // Prevent default Enter key behavior (moving to next row)
            evt.consume();
        }
    }//GEN-LAST:event_module_tableKeyPressed

    private void update_to_file_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_to_file_btnActionPerformed
        if (module_table.isEditing()) {
            module_table.getCellEditor().stopCellEditing();
        }
        
        saveTableToFile();
    }//GEN-LAST:event_update_to_file_btnActionPerformed
    
    private void saveTableToFile() {
          if (module_table.isEditing()) module_table.getCellEditor().stopCellEditing();
        DefaultTableModel model = (DefaultTableModel) module_table.getModel();

        try (BufferedWriter bw = new BufferedWriter(new FileWriter("modules.txt"))) {
            for (int row = 0; row < model.getRowCount(); row++) {
                String code = model.getValueAt(row, 0).toString();
                String name = model.getValueAt(row, 1).toString().replace(",", " ");
                String start = model.getValueAt(row, 2).toString();
                String end = model.getValueAt(row, 3).toString();
                String type = model.getValueAt(row, 4).toString();

                bw.write(code + "," + name + "," + start + "," + end + "," + type + ",NA");
                bw.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving modules.txt: " + e.getMessage());
        }
    }
    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new manage_module().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton add_module_btn;
    private javax.swing.JButton clear_btn;
    private javax.swing.JButton delete_btn;
    private javax.swing.JInternalFrame jInternalFrame1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable module_table;
    private javax.swing.JComboBox<String> new_module_end_time;
    private javax.swing.JTextField new_module_name;
    private javax.swing.JComboBox<String> new_module_start_time;
    private javax.swing.JComboBox<String> new_module_type;
    private javax.swing.JButton previous_page_btn;
    private javax.swing.JButton update_to_file_btn;
    // End of variables declaration//GEN-END:variables
}
